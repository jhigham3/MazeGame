using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjectMazeJoshuaHigham;
using System;
using System.Windows.Forms;

namespace MazeUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        
        public void PlayGame_ClickTest()
        {
            TheGame newForm = new TheGame();
            newForm.Show();
            
            Assert.Fail();
        }



    }
}
