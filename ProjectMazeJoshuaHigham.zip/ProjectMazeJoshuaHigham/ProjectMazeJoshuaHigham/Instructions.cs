﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMazeJoshuaHigham
{
    public partial class Instructions : Form
    {
        public Instructions()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(0, 0, 0);
        }

        private void MainMenu_Click(object sender, EventArgs e)
        {
            MainMenu newForm = new MainMenu();
            newForm.Show();
            this.Hide();
        }

        private void Instructions_Load(object sender, EventArgs e)
        {

        }
    }
}
