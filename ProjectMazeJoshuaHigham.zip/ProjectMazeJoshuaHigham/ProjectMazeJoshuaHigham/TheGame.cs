﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMazeJoshuaHigham
{
    public partial class TheGame : Form
    {
        //this is the integers for the character location for collisions

        public int x;
        public int y;
        



        public TheGame()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(0, 0, 0);         
          
            x = 8;
            y = 8;      


        }

        //THis loads the game 

        private void TheGame_Load(object sender, EventArgs e)
        {
          
        }
             


        //This is for the creation of the border around the panel

        private void TheGame_Paint(object sender, PaintEventArgs wall)
        {
            wall.Graphics.FillRectangle(Brushes.LimeGreen, 20, 56, 10, 362);
            wall.Graphics.FillRectangle(Brushes.LimeGreen, 587, 56, 10, 362);
            wall.Graphics.FillRectangle(Brushes.LimeGreen, 31, 46, 554, 10);
            wall.Graphics.FillRectangle(Brushes.LimeGreen, 31, 418, 554, 10);
            
        }
     
        //This is for the movement of the character 

        public void TheGame_Key_down(object sender, KeyEventArgs key)
        {

            if (key.KeyCode == Keys.Up)
            {
                character.Top -= 5;
            }

            if (key.KeyCode == Keys.Down)
            {
                character.Top += 5;
            }

            if (key.KeyCode == Keys.Left)
            {
                character.Left -= 5;
            }

            if (key.KeyCode == Keys.Right)
            {
                character.Left += 5;

            }


            //this stops character moing out of the borders and if they hit the border they will be re directed to the bigining 

            if (character.Left < 0 )
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;
            }

            if (character.Left > 522)
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;
            }

             if (character.Top < 0)
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;
            }

            if (character.Top > 338)
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;
            }

            Collisions();
            Health();
            Walls();

        }


        //This is for the collisions 
        

        public void Walls()
        {
            if (character.Bounds.IntersectsWith(Maze1.Bounds))
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;

            }

            if (character.Bounds.IntersectsWith(Maze2.Bounds))
            {
                character.Location = new Point(x,y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze3.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze4.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze5.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze6.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze7.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze8.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze9.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze10.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze11.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze12.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze13.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze14.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze15.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze16.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze17.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze18.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze19.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }
            if (character.Bounds.IntersectsWith(Maze20.Bounds))
            {
                character.Location = new Point(x, y);
                Life.Value -= 5;

            }



        }

        //These are for the collisions
        //If the character interacts with a cherry it will move to inventory
        //the inventory image will be replaced with the cherry
        //the cherry image will then leave the screen
        //and if there is an action with collecting a cherry the wall will disapear
        //finally if the character bounds the treasure image the game will be won

        public void Collisions()
        {
            if (character.Bounds.IntersectsWith(Cherry_01.Bounds))
            {
                AddToInv(Cherry_01);
                Inv_01.Image = Cherry_01.Image;
                Cherry_01.Top = 2000;
                Maze3.Top = 2000;
            }
            else if (character.Bounds.IntersectsWith(Cherry_02.Bounds))
            {
                AddToInv(Cherry_02);
                Inv_02.Image = Cherry_02.Image;
                Cherry_02.Top = 2000;
                Maze20.Top = 2000;

            }
            else if (character.Bounds.IntersectsWith(Cherry_03.Bounds))
            {
                AddToInv(Cherry_03);
                Inv_01.Image = Cherry_03.Image;
                Cherry_03.Top = 2000;
                Maze7.Top = 2000;
            }
            else if (character.Bounds.IntersectsWith(Cherry_04.Bounds))
            {
                AddToInv(Cherry_04);
                Inv_01.Image = Cherry_04.Image;
                Maze18.Top = 2000;
            }

            //once all items are collected you can then access the treasure and win the game

            if (character.Bounds.IntersectsWith(Treasure.Bounds))
            {
                WinGame newForm = new WinGame();
                newForm.Show();
                this.Hide();
            }
          

        }

        //Within this i have used tags so that it dosent matter what order you collect the inventory in
        //THe inventory will always populate cronologacly and shift over to the next after each collection

        public void AddToInv(PictureBox item)
        {
            if (Inv_01.Tag == null)
            {
                Inv_01.Image = item.Image;
                Inv_01.Tag = item.Tag;
                item.Top = 2000;
            }
            else if (Inv_02.Tag == null)
            {
                Inv_02.Image = item.Image;
                Inv_02.Tag = item.Tag;
                item.Top = 2000;
            }
            else if (Inv_03.Tag == null)
            {
                Inv_03.Image = item.Image;
                Inv_03.Tag = item.Tag;
                item.Top = 2000;
            }
            else if (Inv_04.Tag == null)
            {
                Inv_04.Image = item.Image;
                Inv_04.Tag = item.Tag;
                item.Top = 2000;
            }

        }

        //Below is the health of the cjaracter wich will decrease if it hits a tree and if health goes to 0 it ends the game 

        public void Health()
        {
                        
            if (Life.Value <= 0)
            {
                FailGame newForm = new FailGame();
                newForm.Show();
                this.Hide();
            }
            
            //if the character collides with the buhes, 25% of life will be lost and be sent back to the start point 

            if (character.Bounds.IntersectsWith(tree_01.Bounds))
            {
                Life.Value -= 25;
                character.Location = new Point(16, 15);

            }
            if (character.Bounds.IntersectsWith(tree_02.Bounds))
            {
                Life.Value -= 25;
                character.Location = new Point(16, 15);

            }

            if (character.Bounds.IntersectsWith(tree_03.Bounds))
            {
                Life.Value -= 25;
                character.Location = new Point(16, 15);

            }
        }
    }
}
