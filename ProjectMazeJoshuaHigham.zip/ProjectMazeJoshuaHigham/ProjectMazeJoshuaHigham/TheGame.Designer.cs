﻿namespace ProjectMazeJoshuaHigham
{
    partial class TheGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Life = new System.Windows.Forms.ProgressBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tree_03 = new System.Windows.Forms.PictureBox();
            this.Maze17 = new System.Windows.Forms.Label();
            this.Maze16 = new System.Windows.Forms.Label();
            this.Maze18 = new System.Windows.Forms.Label();
            this.Maze15 = new System.Windows.Forms.Label();
            this.Maze14 = new System.Windows.Forms.Label();
            this.Maze13 = new System.Windows.Forms.Label();
            this.tree_02 = new System.Windows.Forms.PictureBox();
            this.Maze12 = new System.Windows.Forms.Label();
            this.Maze20 = new System.Windows.Forms.Label();
            this.Maze11 = new System.Windows.Forms.Label();
            this.Maze10 = new System.Windows.Forms.Label();
            this.Maze9 = new System.Windows.Forms.Label();
            this.Maze19 = new System.Windows.Forms.Label();
            this.Treasure = new System.Windows.Forms.PictureBox();
            this.Maze8 = new System.Windows.Forms.Label();
            this.Maze7 = new System.Windows.Forms.Label();
            this.Maze6 = new System.Windows.Forms.Label();
            this.Maze5 = new System.Windows.Forms.Label();
            this.Maze4 = new System.Windows.Forms.Label();
            this.Maze3 = new System.Windows.Forms.Label();
            this.Maze2 = new System.Windows.Forms.Label();
            this.Maze1 = new System.Windows.Forms.Label();
            this.tree_01 = new System.Windows.Forms.PictureBox();
            this.Cherry_04 = new System.Windows.Forms.PictureBox();
            this.Cherry_03 = new System.Windows.Forms.PictureBox();
            this.Cherry_02 = new System.Windows.Forms.PictureBox();
            this.Cherry_01 = new System.Windows.Forms.PictureBox();
            this.character = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Inv_02 = new System.Windows.Forms.PictureBox();
            this.Inv_03 = new System.Windows.Forms.PictureBox();
            this.Inv_04 = new System.Windows.Forms.PictureBox();
            this.Inv_01 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tree_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Treasure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.character)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_01)).BeginInit();
            this.SuspendLayout();
            // 
            // Life
            // 
            this.Life.Location = new System.Drawing.Point(58, 9);
            this.Life.Name = "Life";
            this.Life.Size = new System.Drawing.Size(129, 17);
            this.Life.TabIndex = 0;
            this.Life.Value = 100;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tree_03);
            this.panel1.Controls.Add(this.Maze17);
            this.panel1.Controls.Add(this.Maze16);
            this.panel1.Controls.Add(this.Maze18);
            this.panel1.Controls.Add(this.Maze15);
            this.panel1.Controls.Add(this.Maze14);
            this.panel1.Controls.Add(this.Maze13);
            this.panel1.Controls.Add(this.tree_02);
            this.panel1.Controls.Add(this.Maze12);
            this.panel1.Controls.Add(this.Maze20);
            this.panel1.Controls.Add(this.Maze11);
            this.panel1.Controls.Add(this.Maze10);
            this.panel1.Controls.Add(this.Maze9);
            this.panel1.Controls.Add(this.Maze19);
            this.panel1.Controls.Add(this.Treasure);
            this.panel1.Controls.Add(this.Maze8);
            this.panel1.Controls.Add(this.Maze7);
            this.panel1.Controls.Add(this.Maze6);
            this.panel1.Controls.Add(this.Maze5);
            this.panel1.Controls.Add(this.Maze4);
            this.panel1.Controls.Add(this.Maze3);
            this.panel1.Controls.Add(this.Maze2);
            this.panel1.Controls.Add(this.Maze1);
            this.panel1.Controls.Add(this.tree_01);
            this.panel1.Controls.Add(this.Cherry_04);
            this.panel1.Controls.Add(this.Cherry_03);
            this.panel1.Controls.Add(this.Cherry_02);
            this.panel1.Controls.Add(this.Cherry_01);
            this.panel1.Controls.Add(this.character);
            this.panel1.Location = new System.Drawing.Point(31, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(554, 362);
            this.panel1.TabIndex = 1;
            this.panel1.Tag = "";
            // 
            // tree_03
            // 
            this.tree_03.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.tree8b;
            this.tree_03.Location = new System.Drawing.Point(204, 204);
            this.tree_03.Name = "tree_03";
            this.tree_03.Size = new System.Drawing.Size(25, 18);
            this.tree_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tree_03.TabIndex = 28;
            this.tree_03.TabStop = false;
            this.tree_03.Tag = "Bush";
            // 
            // Maze17
            // 
            this.Maze17.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze17.Location = new System.Drawing.Point(277, 208);
            this.Maze17.Name = "Maze17";
            this.Maze17.Size = new System.Drawing.Size(178, 5);
            this.Maze17.TabIndex = 27;
            // 
            // Maze16
            // 
            this.Maze16.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze16.Location = new System.Drawing.Point(166, 166);
            this.Maze16.Name = "Maze16";
            this.Maze16.Size = new System.Drawing.Size(335, 5);
            this.Maze16.TabIndex = 26;
            // 
            // Maze18
            // 
            this.Maze18.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze18.Location = new System.Drawing.Point(496, 132);
            this.Maze18.Name = "Maze18";
            this.Maze18.Size = new System.Drawing.Size(5, 39);
            this.Maze18.TabIndex = 25;
            // 
            // Maze15
            // 
            this.Maze15.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze15.Location = new System.Drawing.Point(166, 170);
            this.Maze15.Name = "Maze15";
            this.Maze15.Size = new System.Drawing.Size(5, 68);
            this.Maze15.TabIndex = 24;
            // 
            // Maze14
            // 
            this.Maze14.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze14.Location = new System.Drawing.Point(166, 233);
            this.Maze14.Name = "Maze14";
            this.Maze14.Size = new System.Drawing.Size(55, 5);
            this.Maze14.TabIndex = 23;
            // 
            // Maze13
            // 
            this.Maze13.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze13.Location = new System.Drawing.Point(216, 238);
            this.Maze13.Name = "Maze13";
            this.Maze13.Size = new System.Drawing.Size(5, 39);
            this.Maze13.TabIndex = 22;
            // 
            // tree_02
            // 
            this.tree_02.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.tree8b;
            this.tree_02.Location = new System.Drawing.Point(155, 294);
            this.tree_02.Name = "tree_02";
            this.tree_02.Size = new System.Drawing.Size(25, 18);
            this.tree_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tree_02.TabIndex = 21;
            this.tree_02.TabStop = false;
            this.tree_02.Tag = "Bush";
            // 
            // Maze12
            // 
            this.Maze12.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze12.Location = new System.Drawing.Point(221, 272);
            this.Maze12.Name = "Maze12";
            this.Maze12.Size = new System.Drawing.Size(235, 5);
            this.Maze12.TabIndex = 20;
            // 
            // Maze20
            // 
            this.Maze20.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze20.Location = new System.Drawing.Point(194, 90);
            this.Maze20.Name = "Maze20";
            this.Maze20.Size = new System.Drawing.Size(5, 39);
            this.Maze20.TabIndex = 19;
            // 
            // Maze11
            // 
            this.Maze11.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze11.Location = new System.Drawing.Point(451, 208);
            this.Maze11.Name = "Maze11";
            this.Maze11.Size = new System.Drawing.Size(5, 69);
            this.Maze11.TabIndex = 18;
            // 
            // Maze10
            // 
            this.Maze10.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze10.Location = new System.Drawing.Point(451, 208);
            this.Maze10.Name = "Maze10";
            this.Maze10.Size = new System.Drawing.Size(50, 5);
            this.Maze10.TabIndex = 17;
            // 
            // Maze9
            // 
            this.Maze9.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze9.Location = new System.Drawing.Point(499, 208);
            this.Maze9.Name = "Maze9";
            this.Maze9.Size = new System.Drawing.Size(5, 117);
            this.Maze9.TabIndex = 16;
            // 
            // Maze19
            // 
            this.Maze19.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze19.Location = new System.Drawing.Point(124, 124);
            this.Maze19.Name = "Maze19";
            this.Maze19.Size = new System.Drawing.Size(377, 5);
            this.Maze19.TabIndex = 15;
            // 
            // Treasure
            // 
            this.Treasure.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.VibrantShorttermElectriceel_max_1mb;
            this.Treasure.Location = new System.Drawing.Point(145, 95);
            this.Treasure.Name = "Treasure";
            this.Treasure.Size = new System.Drawing.Size(33, 28);
            this.Treasure.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Treasure.TabIndex = 14;
            this.Treasure.TabStop = false;
            // 
            // Maze8
            // 
            this.Maze8.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze8.Location = new System.Drawing.Point(127, 320);
            this.Maze8.Name = "Maze8";
            this.Maze8.Size = new System.Drawing.Size(377, 5);
            this.Maze8.TabIndex = 13;
            // 
            // Maze7
            // 
            this.Maze7.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze7.Location = new System.Drawing.Point(124, 312);
            this.Maze7.Name = "Maze7";
            this.Maze7.Size = new System.Drawing.Size(5, 50);
            this.Maze7.TabIndex = 12;
            // 
            // Maze6
            // 
            this.Maze6.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze6.Location = new System.Drawing.Point(124, 90);
            this.Maze6.Name = "Maze6";
            this.Maze6.Size = new System.Drawing.Size(5, 232);
            this.Maze6.TabIndex = 11;
            // 
            // Maze5
            // 
            this.Maze5.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze5.Location = new System.Drawing.Point(38, 318);
            this.Maze5.Name = "Maze5";
            this.Maze5.Size = new System.Drawing.Size(50, 5);
            this.Maze5.TabIndex = 10;
            // 
            // Maze4
            // 
            this.Maze4.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze4.Location = new System.Drawing.Point(38, 86);
            this.Maze4.Name = "Maze4";
            this.Maze4.Size = new System.Drawing.Size(5, 232);
            this.Maze4.TabIndex = 9;
            // 
            // Maze3
            // 
            this.Maze3.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze3.Location = new System.Drawing.Point(-5, 86);
            this.Maze3.Name = "Maze3";
            this.Maze3.Size = new System.Drawing.Size(50, 5);
            this.Maze3.TabIndex = 8;
            // 
            // Maze2
            // 
            this.Maze2.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze2.Location = new System.Drawing.Point(41, 86);
            this.Maze2.Name = "Maze2";
            this.Maze2.Size = new System.Drawing.Size(515, 5);
            this.Maze2.TabIndex = 7;
            // 
            // Maze1
            // 
            this.Maze1.BackColor = System.Drawing.Color.LimeGreen;
            this.Maze1.Location = new System.Drawing.Point(0, 45);
            this.Maze1.Name = "Maze1";
            this.Maze1.Size = new System.Drawing.Size(511, 5);
            this.Maze1.TabIndex = 6;
            // 
            // tree_01
            // 
            this.tree_01.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.tree8b;
            this.tree_01.Location = new System.Drawing.Point(93, 263);
            this.tree_01.Name = "tree_01";
            this.tree_01.Size = new System.Drawing.Size(25, 18);
            this.tree_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tree_01.TabIndex = 5;
            this.tree_01.TabStop = false;
            this.tree_01.Tag = "Bush";
            // 
            // Cherry_04
            // 
            this.Cherry_04.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.Cherries;
            this.Cherry_04.Location = new System.Drawing.Point(402, 238);
            this.Cherry_04.Name = "Cherry_04";
            this.Cherry_04.Size = new System.Drawing.Size(33, 28);
            this.Cherry_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cherry_04.TabIndex = 4;
            this.Cherry_04.TabStop = false;
            this.Cherry_04.Tag = "cherry";
            // 
            // Cherry_03
            // 
            this.Cherry_03.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.Cherries;
            this.Cherry_03.Location = new System.Drawing.Point(49, 105);
            this.Cherry_03.Name = "Cherry_03";
            this.Cherry_03.Size = new System.Drawing.Size(33, 28);
            this.Cherry_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cherry_03.TabIndex = 3;
            this.Cherry_03.TabStop = false;
            this.Cherry_03.Tag = "cherry";
            // 
            // Cherry_02
            // 
            this.Cherry_02.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.Cherries;
            this.Cherry_02.Location = new System.Drawing.Point(461, 216);
            this.Cherry_02.Name = "Cherry_02";
            this.Cherry_02.Size = new System.Drawing.Size(33, 28);
            this.Cherry_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cherry_02.TabIndex = 2;
            this.Cherry_02.TabStop = false;
            this.Cherry_02.Tag = "cherry";
            // 
            // Cherry_01
            // 
            this.Cherry_01.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.Cherries;
            this.Cherry_01.Location = new System.Drawing.Point(280, 53);
            this.Cherry_01.Name = "Cherry_01";
            this.Cherry_01.Size = new System.Drawing.Size(33, 28);
            this.Cherry_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cherry_01.TabIndex = 1;
            this.Cherry_01.TabStop = false;
            this.Cherry_01.Tag = "cherry";
            // 
            // character
            // 
            this.character.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.Character;
            this.character.Location = new System.Drawing.Point(12, 11);
            this.character.Name = "character";
            this.character.Size = new System.Drawing.Size(31, 31);
            this.character.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.character.TabIndex = 0;
            this.character.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Health";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(377, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Inventory";
            // 
            // Inv_02
            // 
            this.Inv_02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Inv_02.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.BlackBox;
            this.Inv_02.Location = new System.Drawing.Point(526, 5);
            this.Inv_02.Name = "Inv_02";
            this.Inv_02.Size = new System.Drawing.Size(21, 21);
            this.Inv_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Inv_02.TabIndex = 9;
            this.Inv_02.TabStop = false;
            // 
            // Inv_03
            // 
            this.Inv_03.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Inv_03.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.BlackBox;
            this.Inv_03.Location = new System.Drawing.Point(486, 5);
            this.Inv_03.Name = "Inv_03";
            this.Inv_03.Size = new System.Drawing.Size(21, 21);
            this.Inv_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Inv_03.TabIndex = 8;
            this.Inv_03.TabStop = false;
            // 
            // Inv_04
            // 
            this.Inv_04.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Inv_04.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.BlackBox;
            this.Inv_04.Location = new System.Drawing.Point(445, 4);
            this.Inv_04.Name = "Inv_04";
            this.Inv_04.Size = new System.Drawing.Size(21, 21);
            this.Inv_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Inv_04.TabIndex = 7;
            this.Inv_04.TabStop = false;
            // 
            // Inv_01
            // 
            this.Inv_01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Inv_01.Image = global::ProjectMazeJoshuaHigham.Properties.Resources.BlackBox;
            this.Inv_01.Location = new System.Drawing.Point(564, 5);
            this.Inv_01.Name = "Inv_01";
            this.Inv_01.Size = new System.Drawing.Size(21, 21);
            this.Inv_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Inv_01.TabIndex = 6;
            this.Inv_01.TabStop = false;
            // 
            // TheGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 443);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Inv_02);
            this.Controls.Add(this.Inv_03);
            this.Controls.Add(this.Inv_04);
            this.Controls.Add(this.Inv_01);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Life);
            this.Name = "TheGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TheGame";
            this.Load += new System.EventHandler(this.TheGame_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.TheGame_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TheGame_Key_down);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tree_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Treasure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cherry_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.character)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inv_01)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar Life;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox Cherry_01;
        private System.Windows.Forms.PictureBox character;
        private System.Windows.Forms.PictureBox Cherry_04;
        private System.Windows.Forms.PictureBox Cherry_03;
        private System.Windows.Forms.PictureBox Cherry_02;
        private System.Windows.Forms.PictureBox tree_01;
        private System.Windows.Forms.PictureBox Inv_01;
        private System.Windows.Forms.PictureBox Inv_04;
        private System.Windows.Forms.PictureBox Inv_03;
        private System.Windows.Forms.PictureBox Inv_02;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Maze1;
        private System.Windows.Forms.Label Maze3;
        private System.Windows.Forms.Label Maze2;
        private System.Windows.Forms.Label Maze4;
        private System.Windows.Forms.Label Maze5;
        private System.Windows.Forms.Label Maze6;
        private System.Windows.Forms.Label Maze7;
        private System.Windows.Forms.Label Maze8;
        private System.Windows.Forms.PictureBox Treasure;
        private System.Windows.Forms.Label Maze9;
        private System.Windows.Forms.Label Maze19;
        private System.Windows.Forms.Label Maze20;
        private System.Windows.Forms.Label Maze11;
        private System.Windows.Forms.Label Maze10;
        private System.Windows.Forms.Label Maze12;
        private System.Windows.Forms.PictureBox tree_02;
        private System.Windows.Forms.Label Maze17;
        private System.Windows.Forms.Label Maze16;
        private System.Windows.Forms.Label Maze18;
        private System.Windows.Forms.Label Maze15;
        private System.Windows.Forms.Label Maze14;
        private System.Windows.Forms.Label Maze13;
        private System.Windows.Forms.PictureBox tree_03;
    }
}