﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMazeJoshuaHigham
{
    public partial class WinGame : Form
    {
        public WinGame()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(0, 0, 0);
        }

        private void WInMainMenu_Click(object sender, EventArgs e)
        {
            MainMenu newForm = new MainMenu();
            newForm.Show();
            this.Hide();
        }
    }
}
