﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMazeJoshuaHigham
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(0, 0, 0);
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        //Plays the game 

        public void PlayGame_Click(object sender, EventArgs e)
        {

            {
                TheGame newForm = new TheGame();
                newForm.Show();
                this.Hide();
                                
            }

        }

        //this will take you to the instructions page

        private void Instructions_Click(object sender, EventArgs e)
        {
            Instructions newForm = new Instructions();
            newForm.Show();
            this.Hide();
        }
    }
}
